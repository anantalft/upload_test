module Api
  module V1
    class TranslationsController < BaseController
      respond_to :json, :xml, :pdf, :png, :gif

      after_action :track_authenticated_request!

      def show
        translation = Translation.
          joins(:paraphrase, :locale).
          merge(Paraphrase.where(key: params[:paraphrase_id])).
          merge(Locale.where(code: params[:locale_code])).
          first!

        authorize translation
        document = LabelMaker.new(translation, params).build

        if document[:font_size].to_i < params[:min_font_size].to_i
          respond_with translation, status: 400
        else
          query_data = [translation.locale_code, params[:sig_id]].join("/")
          QueryLog::Tracker.new("translations", current_user, query_data, translation.token).run

          respond_with translation
        end
      end
    end
  end
end
