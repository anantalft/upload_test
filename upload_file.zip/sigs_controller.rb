module Api
  module V1
    class SigsController < BaseController
      respond_to :json, :xml

      def show
        sig = Sig::Lookup.new(token: CGI.unescape(params[:id])).run

        query_data = [sig.token, params[:drug], params[:code]].compact.join(";")
        token_data = sig.paraphrases.map(&:token).join(";")
        QueryLog::Tracker.new("sig", current_user, query_data, token_data).run
        respond_with sig, status: sig.paraphrases.length.zero? ? 404 : 200
      end
    end
  end
end
