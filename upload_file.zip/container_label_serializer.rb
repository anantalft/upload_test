module Api
  module V1
    class ContainerLabelSerializer < ApplicationSerializer
      root "container-label"

      attribute :id
      attribute :drug_id, key: "drug-id"
      attribute :locale_id, key: "locale-id"
      attribute :custom
      attribute :reference
      attribute :created_at, key: "created-at"
      attribute :sig_token, key: "sig-token"
      attribute :paraphrase_token, key: "paraphrase-token"
      attribute :translation_token, key: "translation-token"
      has_many :warning_label_selections, key: "container-label-warnings", serializer: ContainerLabelWarningLabelSelectionSerializer

      def drug_id
        object.drug_id || NullId.instance
      end

      def sig_token
        object.sig_token || ""
      end

      def paraphrase_token
        object.paraphrase_token || ""
      end

      def warning_label_selections
        object.warning_label_selections.order(:position)
      end

      def include_tokens?
        options[:include_tokens]
      end

      alias :include_sig_token? :include_tokens?
      alias :include_paraphrase_token? :include_tokens?
      alias :include_translation_token? :include_tokens?
      alias :include_warning_label_selections? :include_tokens?
    end
  end
end
