class ContainerLabel < ApplicationRecord
  class WarningLabelSelection < ApplicationRecord
    self.table_name = "container_label_warnings"

    belongs_to :container_label, inverse_of: :warning_label_selections
    belongs_to :warning_label, foreign_key: :warning_id
    belongs_to :warning_label_translation, class_name: "WarningLabel::Translation", foreign_key: :warning_translation_id

    validates :warning_label, associated: true
    validates :warning_label_id, presence: true

    alias_attribute :warning_label_id, :warning_id

    def self.with_tokens
      joins(:warning_label, :warning_label_translation).
        select(arel_table[Arel.star]).
        select(WarningLabel.arel_table[:token].as("warning_label_token")).
        select(WarningLabel::Translation.arel_table[:token].as("warning_label_translation_token"))
    end

    def warning_label_token
      attributes.fetch("warning_label_token") do
        warning_label ? warning_label.token : "Error: warning id is invalid."
      end
    end

    def warning_label_translation_token
      attributes.fetch("warning_label_translation_token") do
        if warning_label_translation
          warning_label_translation.token
        elsif warning_label
          warning_label.token
        else
          "Error: warning id is invalid."
        end
      end
    end
  end
end
