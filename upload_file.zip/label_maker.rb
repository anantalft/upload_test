class LabelMaker
  def initialize(model, options = {})
    @token = model.token
    @options = Options.new

    @options.font_size = options["font_size"]
    @options.paper = options["paper"]
    @options.orientation = options["orientation"]
    @options.font_name = model.locale.font_name
  end

  def build
    @options.renderer.new(@token, @options.to_h).run
  end

  module Rendering
    class FontSizeAuto
      MAX_ITERATIONS = 50

      def initialize(token, options)
        @token = token
        @options = options.dup
      end

      # Adjusts the font size up or down until:
      # * It stops changing to within 2 decimal places
      # * The document is one page long
      #
      # Reduces the step size when the page count becomes 1 or changes to more than 1
      def run
        # Setup initial variables. Where a value doesn't exist, set it to 0
        iteration_count = 0
        last_font_size = 0
        font_size = 24
        last_page_count = 0

        # The step size is intentionally less than half of the starting font size to avoid a
        # zero font size or font size less than zero.
        step_size = 11

        document = build_document(font_size: font_size)
        page_count = document[:document].page_count

        # Stop when:
        # * The number of pages is 1
        # * The font size isn't change for 2 decimal places
        # OR
        # * We've exceded the max number of iterations
        #
        # `page_count` check is necessary because we'll be oscillating between 1 and 2 pages as
        # the `step_size` decreases
        until page_count == 1 && font_size.round(2) == last_font_size.round(2) || iteration_count > MAX_ITERATIONS
          last_font_size = font_size

          # if we're at more than 1 page, reduce the font size, otherwise, increase the font
          # size
          if page_count > 1
            font_size -= step_size
          else
            font_size += step_size
          end

          last_page_count = page_count

          document = build_document(font_size: font_size)
          page_count = document[:document].page_count

          # if we've transitioned into or out of 1 page, reduce the step size
          if last_page_count > 1 && page_count == 1 || last_page_count == 1 && page_count > 1
            step_size = step_size / 2.0
          end

          iteration_count += 1
        end

        document
      end

      def build_document(font_size:)
        FontSizeDefined.new(@token, @options.merge(font_size: font_size)).run
      end
    end

    class FontSizeDefined
      def initialize(token, options)
        @token = token
        @font_size = options.delete(:font_size)
        @font_name = options.delete(:font_name)
        @options = options
      end

      def run
        document = PDF::Wrapper.new(StringIO.new, @options).tap do |document|
          document.font @font_name
          document.text "<b>#{@token}</b>", font_size: @font_size, markup: :pango
          document.finish
        end
        {"document": document, font_size: @font_size}
      end
    end
  end

  class Options
    ORIENTATIONS = {
      landscape: :landscape,
      portrait: :portrait
    }

    STANDARD_DIMENSIONS = PDF::Wrapper::PAGE_SIZES

    # Custom sizes have an unknown history. They used to be listed as a series of calculations
    # based on DPI.
    #
    # The values were determined using `Rational` for fractional numbers floats where that
    # precision was known. Each dimension was then mulitplied by the DPI value and converted to
    # an integer.
    #
    # The values below are the results of those calculations, grouped by DPI and ordered from
    # lowest DPI to highest. The intended dimensions are listed above the paper size name.
    #
    # The DPI number does not seem to affect the actual pixel density of the image because the
    # font size isn't adjusted. We're unable to correct the paper sizes because it would
    # disrupt the current output of the API.  None of our API partners have complained so it's
    # best to leave it as-is.
    CUSTOM_DIMENSIONS = {
      ## Unknown DPI
      # 1.54 x 0.41
      "RX0" => [148, 39],
      # 2.57 x 0.7
      "RX1" => [247, 67],
      # 5.25 x 1.75
      "RX2" => [504, 168],

      # "72 DPI"
      # 5.51 x 1.10
      "srs-140x28" => [396, 79],
      # 7.87 x 1.57
      "srs-200x40" => [566, 113],
      # 2.95 x 0.59
      "srs-75x15" => [212, 42],
      # 3.66 x 0.59
      "srs-93x15" => [263, 42],
      # 2.44 x 0.39
      "srs-62x10" => [175, 28],
      # 2.75 * 1.5
      # "SP1" => [198, 108],

      ## "96 DPI"
      # 2.46 x 0.52
      "RX13" => [236, 49],
      # 1.89 x 0.41
      "RX14" => [181, 39],
      # 3.86 x 0.64
      "RX15" => [370, 61],

      # 2.67 x 0.5 (150 DPI)
      "RX22" => [400, 75],

      # "203 DPI"
      # 2.46 x 0.52
      "RX16" => [499, 105],
      # 1.892 x 0.291
      "RX17" => [384, 59],
      # 2.438 x 0.814
      "RX18" => [494, 165],
      # 2.25 x 0.25
      "RX19" => [456, 50],
      # 2.438 x 0.754 (203 DPI)
      "RX21" => [494, 153],
      # 2.40 x 0.65
      "RX23" => [487, 131],
      # 1.50 x 0.50
      "RX24" => [304, 101],
      # 3.00 x 0.50
      "RX25" => [609, 101],
      # 3.622 x 0.167
      "envision-12" => [735, 33],
      # 3.622 x 0.194
      "envision-14" => [735, 39],
      # 3.622 x 0.222
      "envision-16" => [735, 45],
      # 3.622 x 0.250
      "envision-18" => [735, 50],
      # 3.622 x 0.278
      "envision-20" => [735, 56],
      # 3.622 x 0.306
      "envision-22" => [735, 62],

      ## "300 DPI"
      # 2.625 x 0.625
      "RX20" => [787, 187],
      # 3.00 x 0.50
      "RX26" => [900, 150],

      ## "302 DPI"
      # 1 9/16 x 3/8
      "RX3" => [471, 113],
      # 1 7/16 x 5/8
      "RX4" => [434, 94],
      # 2 3/4 x 5/8
      "RX5" => [830, 188],
      # 2 3/4 x 1/2
      "RX6" => [830, 151],
      # 2 1/2 x 5/8
      "RX7" => [755, 188],
      # 2 1/2 x 1/2
      "RX8" => [755, 151],
      # 2 1/4 x 5/8
      "RX9" => [679, 188],
      # 2 1/4 x 1/2
      "RX10" => [679, 151],
      # 1 1/2 x 15/16
      "RX11" => [453, 283],
      # 1 1/2 x 11/16
      "RX12" => [453, 207],

      # rite aid pixel dimensions
     "SP1" => [783, 392],
    }

    DEFAULTS = {
      font_size: 12,
      orientation: ORIENTATIONS[:portrait],
      paper: :LETTER
    }

    attr_reader :font_size, :paper, :orientation, :renderer

    attr_accessor :font_name

    def initialize
      @font_size = DEFAULTS.fetch(:font_size)
      @orientation = DEFAULTS.fetch(:orientation)
      @paper = DEFAULTS.fetch(:paper)
      @renderer = Rendering::FontSizeDefined
    end

    def font_size=(value)
      case value
      when /\d+/, Integer
        @font_size = value.to_i
        @renderer = Rendering::FontSizeDefined
      when /auto/i
        @font_size = value
        @renderer = Rendering::FontSizeAuto
      end

      value
    end

    def paper=(value)
      @paper = if CUSTOM_DIMENSIONS.key?(value)
                 CUSTOM_DIMENSIONS[value]
               elsif value && STANDARD_DIMENSIONS.key?(value.to_sym)
                 value.to_sym
               else
                 :LETTER
               end

      value
    end

    def orientation=(value)
      @orientation = case value.presence
                     when /landscape/i
                       ORIENTATIONS[:landscape]
                     when /portrait/i, nil
                       ORIENTATIONS[:portrait]
                     end

      value
    end

    def to_h
      Rails.logger.debug "ORIENTATION: #{orientation}"
      {
        paper: paper,
        font_name: font_name,
        font_size: font_size,
        orientation: orientation
      }
    end
  end
end
