ActionController::Renderers.add :pdf do |object, options|
  self.content_type ||= Mime[:pdf]

  document = LabelMaker.new(object, params).build
  response.headers["X-RxTran-Total-Pages"] = document[:document].page_count.to_s

  document[:document].render
end

ActionController::Renderers.add :png do |object, options|
  self.content_type ||= Mime[:png]

  document = LabelMaker.new(object, params).build
  response.headers["X-RxTran-Total-Pages"] = document[:document].page_count.to_s

  ConvertCommand.new(content: document[:document].render, format: :png).run
end

ActionController::Renderers.add :gif do |object, options|
  self.content_type ||= Mime[:gif]

  document = LabelMaker.new(object, params).build
  response.headers["X-RxTran-Total-Pages"] = document[:document].page_count.to_s

  ConvertCommand.new(content: document[:document].render, format: :gif).run
end
