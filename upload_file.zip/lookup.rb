class Sig < ApplicationRecord
  class Lookup
    attr_reader :token

    def initialize(token:)
      @token = token
    end

    def run
      # skip the call to transduction if we know the sig token is going to be too long to
      # persist
      if @token.length > 1024
        Sig.new
      else
        Sig.find_by(token: @token) || Transduction.new(token: @token).to_sig
      end
    end

    class Transduction
      def initialize(token:)
        @token = token
        @locale_ids_by_code = Locale.pluck(:code, :id).to_h
        @translations_by_locale_code = Request.new(token: @token).run
        @default_locale_translations = @translations_by_locale_code.delete(Locale::DEFAULT_CODE) || {}
      end

      def to_sig
        if @default_locale_translations.empty?
          Sig.new
        else
          Sig.create(token: @token, phrasings: sig_phrasings.compact)
        end
      end

      private

      def sig_phrasings
        @default_locale_translations.each_with_index.map do |token, index|
          if token.length > 1024
            next
          end

          paraphrase = Paraphrase.where(token: token).first_or_initialize
          @translations_by_locale_code.each do |locale_code, translation_tokens|
            translation_token = translation_tokens[index]
            if translation_token.length > 1024
              next
            end

            paraphrase.translations.
              where(locale_id: @locale_ids_by_code[locale_code]).
              first_or_initialize(token: translation_tokens[index])
          end

          if paraphrase.translations.length < @translations_by_locale_code.length
            next
          end

          Phrasing.new(paraphrase: paraphrase, precedence: index)
        end
      end

      class Request
        SERVER = XMLRPC::Client.new("127.0.0.1", "/transduce/", 5000).tap do |server|
          server.timeout = 5
        end

        def initialize(token:)
          @token = token
        end

        def run
          SERVER.call("transduce.sig", @token)
        rescue RuntimeError => error
          Rollbar.error(error, token: @token)
          {}
        end
      end
    end
  end
end
